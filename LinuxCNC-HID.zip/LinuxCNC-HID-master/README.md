# LinuxCNC-HID
LinuxCNC HID Extender
Additional tools to create specialized user interfaces for LinuxCNC

Goals:
   * USB interface
   * More and functional keyboards, pointers, controllers, etc.
   * Connection function buttons, switches, controls, etc.
   * Connection indicator lamps, additional displays.
   * Support for unlimited sets of configurations.
   * LinuxCNC HAL interface.
