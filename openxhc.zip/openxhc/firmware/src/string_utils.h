#pragma once

void int2strprec( int32_t v, char padd, char *o );
void xhc2string( uint16_t iint, uint16_t ifrac, char ipadd, char fpadd, char *o );
void string2int( int32_t value, char padd, char *o );
void string2uint( int32_t value, char padd, char *o );
